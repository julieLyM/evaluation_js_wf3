$(document).ready(function () {
  $('#carouselExampleSlidesOnly').carousel({
    interval: 15000,
    pause: false,
  });

  
  $('#carouselExampleIndicators').carousel({
    interval: 0,
    pause: false,
    cycle: 0,
  });


});
